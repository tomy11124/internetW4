
from __future__ import annotations

from typing import List
from typing import Type

from component.name import Name
from component.role import Role

from event.event import Event
from message.message import Message
from system.channel import Channel

from logcat.logcat import LogCat

class CmdBuy:
    @LogCat.log_func
    def __init__(self, servant: Type[Handler]):
        servant.on(Event.CMD_BUY, self._on_cmd_buy)

    @LogCat.log_func
    def _on_cmd_buy(
        self, e: Event, entity: str = '', args: List[str] = []
    ) -> None:
        if not args:
            text = f'Buy:?'
        else:
            text = f'Buy 說：{" 小朋友才做選擇，我全都要 ".join(args)}'

        Channel.to_role(entity, Message.TEXT, text)

# cmd_buy.py

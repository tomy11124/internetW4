
* stage-0
    1. 建立房間

    1. 設置所有 npc

    1. 設置所有 resources

    1. 設置所有 treasure

* state-1
    1. DEAD --- 初始狀態

    1. RESPAWN --- 重生

    1. LOOT --- 準備戰利品

    1. ALERT --- 搜尋視界

    1. MOVE --- 移動

    1. ... --- 共它

    1. COMBAT --- 戰鬥



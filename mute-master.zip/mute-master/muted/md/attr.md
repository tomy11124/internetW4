
* 屬性
    1. strength: 力量

      + +damage

    1. constitution: 體質

      + +hp (hitpoints)

    1. dexterity:

      + +dodge

    1. intelligence:

      + +critical (-hit)

    1. perception: 感知

      + +parry
      + +aggro_radius (mob)

    1. wisdom:

    1. luck:

      + loot

    1. focus: 專注

     + -parry

    1. spirit: 精神

     + +wp (willpower)

    1. qi: 內力

     + 消耗品


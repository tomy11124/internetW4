
import curses

class Attribute:
    REVERSE = curses.A_REVERSE

# attribute.py

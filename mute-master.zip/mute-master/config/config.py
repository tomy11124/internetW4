
LOGGING = {
    "config": "./.mute/config.json",
    "logfile": "./.mute/log/mute.log"
}

# config.py
